import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CrowdquestionsComponent } from './crowdquestions.component';

describe('CrowdquestionsComponent', () => {
  let component: CrowdquestionsComponent;
  let fixture: ComponentFixture<CrowdquestionsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CrowdquestionsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CrowdquestionsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
