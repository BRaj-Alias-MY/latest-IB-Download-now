import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-intquestiontemplates',
  templateUrl: './intquestiontemplates.component.html',
  styleUrls: ['./intquestiontemplates.component.css']
})
export class IntquestiontemplatesComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
