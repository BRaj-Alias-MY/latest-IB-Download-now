import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BulkquestionsComponent } from './bulkquestions.component';

describe('BulkquestionsComponent', () => {
  let component: BulkquestionsComponent;
  let fixture: ComponentFixture<BulkquestionsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BulkquestionsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BulkquestionsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
